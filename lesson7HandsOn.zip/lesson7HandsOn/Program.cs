﻿using System;

namespace lesson7HandsOn
{
    public class Employee
    {
        public string name;
        public string salary;
        public string hireDate;
        public Employee()
        {
            this.name = "";
            this.salary = "";
            this.hireDate = "";
        }
        public Employee(string name, string salary, string hireDate)
        {
            this.name = name;
            this.salary = salary;
            this.hireDate = hireDate;
        }
        public virtual getName()
        {
            return name;
        }
        public virtual getSalary()
        {

        }
        public virtual hiredDate()
        {

        }
    }
    public class Engineer : Employee
    {
        public virtual string getSalary()
        {
            return "Salary: Sorry, this employee's salary is private.";
        }
        public class SoftwareEngineer : Engineer
        {

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
