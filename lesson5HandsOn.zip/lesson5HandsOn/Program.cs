﻿using System;

namespace lesson5HandsOn
{
    public class Person
    {
        string firstName;
        string lastName;
        string age;
        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                firstName = value;
            }
        }
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                lastName = value;
            }
        }
        public string Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }
        // default constructor
        public Person()
        {
            firstName = "";
            lastName = "";
            age = "";
        }
        public Person(string firstName, string lastName, string age)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.age = age;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person p1 = new Person("Henry", "Boswald", "33");
            Person p2 = new Person("Lola", "Boswald", "31");
            Person p3 = new Person();
            Person p4 = new Person();

            p3.firstName = "Henry";
            p3.lastName = "Boswald";
            p3.age = 33;

            p4.firstName = "Lola";
            p4.lastName = "Boswald";
            p4.age = 31;

            Console.WriteLine(p1);
            Console.WriteLine(p2);
            Console.WriteLine(p3);
            Console.WriteLine(p4);

        }
    }
}
